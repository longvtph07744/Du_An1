package com.example.apptruyentranhh.fragment.tusach;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.apptruyentranhh.ChapActivity;
import com.example.apptruyentranhh.DAO.YeuThichDAO;
import com.example.apptruyentranhh.R;
import com.example.apptruyentranhh.adapter.YeuThich_Adapter;
import com.example.apptruyentranhh.object.Home;
import com.example.apptruyentranhh.object.TruyenYeuThich;
import com.example.apptruyentranhh.object.Truyentranh;

import java.util.ArrayList;
import java.util.List;

public class TuSachFragment extends Fragment {

    GridView gdvdstruyen;
    ArrayList<TruyenYeuThich> truyentranhList;
    YeuThich_Adapter adapter ;
    YeuThichDAO yeuThichDAO;
   List<TruyenYeuThich> dstruyentranh = new ArrayList<>();

//
//
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_theodoi, container, false);
        yeuThichDAO = new YeuThichDAO(getContext());
        gdvdstruyen = root.findViewById(R.id.gdvDSTruyen);

        dstruyentranh = yeuThichDAO.getAllTruyenYeuThich();
//        truyentranhList = (ArrayList<TruyenYeuThich>) yeuThichDAO.getAllTruyenYeuThich();


        adapter = new YeuThich_Adapter(getContext(),0, dstruyentranh);
        gdvdstruyen.setAdapter(adapter);

        setonclick();
        return root;
    }
//

    private void setonclick() {
//        gdvdstruyen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                TruyenYeuThich truyentranh = truyentranhList.get(i);
//                Bundle b = new Bundle();
//                b.putSerializable("truyen", truyentranh);
//
//                Intent intent = new Intent(getContext(), ChapActivity.class);
//                intent.putExtra("data", b);
//                startActivity(intent);
//            }
//        });
    }
//
    private void setup() {
//        gdvdstruyen.setAdapter(adapter);

    }

    private void init() {


    }
}
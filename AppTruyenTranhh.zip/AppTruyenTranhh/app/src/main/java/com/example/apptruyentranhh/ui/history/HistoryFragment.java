package com.example.apptruyentranhh.ui.history;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.apptruyentranhh.ChapActivity;
import com.example.apptruyentranhh.Lich_Su;
import com.example.apptruyentranhh.R;
import com.example.apptruyentranhh.adapter.TruyenTranh_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;

import java.util.ArrayList;


public class HistoryFragment extends Fragment {
    GridView gdvdstruyen;
    ArrayList<Truyentranh> truyentranhArrayList;
    TruyenTranh_Adapter adapter_;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_history, container, false);
        gdvdstruyen = root.findViewById(R.id.gdvDSTruyen);

        init();
        setup();
        setonclick();

        return root;
    }



    private void setonclick() {
        gdvdstruyen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Truyentranh truyentranh = truyentranhArrayList.get(i);
                Bundle b = new Bundle();
                b.putSerializable("truyen", truyentranh);

                Intent intent = new Intent(getContext(), ChapActivity.class);
                intent.putExtra("data", b);
                startActivity(intent);
            }
        });
    }

    private void setup() {
        gdvdstruyen.setAdapter(adapter_);

    }

    private void init() {
        truyentranhArrayList = new ArrayList<>();
        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca", "Đã xem", "https://3.bp.blogspot.com/-uKfnUKn4l1U/WBNE061U2pI/AAAAAAAAMlU/1w4WeeLfdJ0/hatsukoi-zombie.jpg"));
        truyentranhArrayList.add(new Truyentranh("Thiên thần ", "Đã xem", "https://3.bp.blogspot.com/-22po55yUNXo/Wo9z08YchEI/AAAAAAAAP0M/HOo5VSjyXgs3YHLNPczvLJNH5OMlz6_NwCHMYCw/trai-tim-va-than-xac-blush-dc-himitsu"));
        truyentranhArrayList.add(new Truyentranh("Đường Tây Tử", "Đã xem", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));
        truyentranhArrayList.add(new Truyentranh("Tân Tác Long Hổ Môn", "Đã xem", "https://3.bp.blogspot.com/-fUUIZ4Fh0y4/Wo9nz9jZ3TI/AAAAAAAANi4/oJ28Retz8BYvLobtj3kZC1Qq9RtDoF5pwCHMYCw/vuong-tuoc-tu-huu-bao-boi"));
        truyentranhArrayList.add(new Truyentranh("Danh Môn Chí Ái", "Đã xem", "https://3.bp.blogspot.com/-kgHjaI_K7GU/WqdkxteJZ3I/AAAAAAAARXI/ax6XxDzfl1kW-u88I4_GUDgUsi57OeyYwCHMYCw/nhan-chat-tinh-nhan"));

        adapter_ = new TruyenTranh_Adapter(getContext(), 0, truyentranhArrayList);


    }
}
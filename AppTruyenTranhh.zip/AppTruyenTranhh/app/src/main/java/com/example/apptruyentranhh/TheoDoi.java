package com.example.apptruyentranhh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import com.example.apptruyentranhh.adapter.TruyenTranhDaDoc_Adapter;
import com.example.apptruyentranhh.adapter.TruyenTranh_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TheoDoi extends AppCompatActivity {

    public ViewFlipper viewFlipper ;
    GridView gdvdstruyen;
    ArrayList<Truyentranh> truyentranhArrayList;
    TruyenTranhDaDoc_Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theo_doi);

        gdvdstruyen = findViewById(R.id.gdvDSTruyen);
        viewFlipper = findViewById(R.id.vf);
        Side_Anh();
        init();
        setup();
        setonclick();
    }

    private void setonclick() {
        gdvdstruyen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Truyentranh truyentranh = truyentranhArrayList.get(i);
                Bundle b = new Bundle();
                b.putSerializable("truyen",truyentranh);

                Intent intent = new Intent(TheoDoi.this,ChapActivity.class);
                intent.putExtra("data",b);
                startActivity(intent);
            }
        });
    }

    private void setup() {
        gdvdstruyen.setAdapter(adapter);

    }

    private void init() {
        truyentranhArrayList = new ArrayList<>();
        truyentranhArrayList.add(new Truyentranh("Ta Là Đại Thần  ","Chapter 100","https://3.bp.blogspot.com/-gBNk3Lqqj0k/W8ya_FF2MxI/AAAAAAAAaFg/PCTRbB4KjEktAjYKoj8JLB6_uLZLBj70gCHMYCw/ta-la-dai-than-tien") );

        adapter = new TruyenTranhDaDoc_Adapter(this,0,truyentranhArrayList);


    }


    private void Side_Anh() {
        ArrayList<String> sidearm = new ArrayList<>();
        sidearm.add("https://thegioidienanh.vn/stores/news_dataimages/huonggiang/052018/05/10/3827_ThYn_YYng_YYt_ViYt_2.jpg");
        sidearm.add("https://media.ohay.tv/v1/content/2015/09/1-ohay-tv-16163.jpg");
        sidearm.add("https://media.ohay.tv/v1/content/2015/09/2-ohay-tv-40982.jpg");
        sidearm.add("https://i.imgur.com/O3L9MOt.png");

        sidearm.add("https://genknews.genkcdn.vn/2019/5/7/photo-1-1557228146635626126519-crop-1557228203131655890479.png");






        for (int i = 0; i < sidearm.size(); i++) {

            ImageView imageView = new ImageView(getApplicationContext());


            Picasso.with(getApplicationContext()).load(sidearm.get(i)).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            Log.e(imageView.toString(),"aaaa");
            viewFlipper.addView(imageView);
        }
        viewFlipper.setFlipInterval(5000);
        viewFlipper.setAutoStart(true);
        Animation animation_side = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.silde);
        Animation animation_side_out = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.silde_ou);
        viewFlipper.setInAnimation(animation_side);
        viewFlipper.setInAnimation(animation_side_out);

    }


    public void thuvien(View view) {
        Intent intent = new Intent(TheoDoi.this,Thu_Vien.class);
        startActivity(intent);
    }



}

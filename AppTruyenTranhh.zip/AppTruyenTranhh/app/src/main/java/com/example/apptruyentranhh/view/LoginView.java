package com.example.apptruyentranhh.view;

public interface LoginView {

    void loginFail();

    void loginSuccessful();

    void navigateHome();

    void setErrorUsername();

    void setErrorPassword();
}

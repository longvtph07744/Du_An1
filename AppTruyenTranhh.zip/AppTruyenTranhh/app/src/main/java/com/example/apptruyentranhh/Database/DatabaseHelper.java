package com.example.apptruyentranhh.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.apptruyentranhh.DAO.HomeDAO;
import com.example.apptruyentranhh.DAO.YeuThichDAO;


public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME ="AppTruyenTranh";
    public static final int VERSION = 2;


    public DatabaseHelper(Context context) {super(context, DATABASE_NAME, null,VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        db.execSQL(HomeDAO.SQL_TRANG_CHU);
        db.execSQL(YeuThichDAO.SQL_TRUYEN_YEU_THICH);




    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }
}

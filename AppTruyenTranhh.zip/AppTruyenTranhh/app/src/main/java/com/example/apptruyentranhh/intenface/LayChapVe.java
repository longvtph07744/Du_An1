package com.example.apptruyentranhh.intenface;

public interface LayChapVe {
    void batDau();
    void ketThuc(String data);
    void  biLoi();

}

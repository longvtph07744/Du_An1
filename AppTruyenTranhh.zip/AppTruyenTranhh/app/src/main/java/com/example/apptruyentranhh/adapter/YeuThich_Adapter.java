package com.example.apptruyentranhh.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.apptruyentranhh.R;
import com.example.apptruyentranhh.object.Home;
import com.example.apptruyentranhh.object.TruyenYeuThich;

import java.util.List;


public class YeuThich_Adapter extends ArrayAdapter<TruyenYeuThich> {
    private Context ct;
    private List<TruyenYeuThich> arr;


    public YeuThich_Adapter(Context context, int resource, List<TruyenYeuThich> n) {
        super(context, resource, n);

        this.ct = context;

        this.arr =n;
    }






    @Override
    public View getView(int position, View convertView,  ViewGroup parent) {
        if (convertView==null){
            LayoutInflater inflater = (LayoutInflater)ct.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.item_truyen,null);
        }
        if (arr.size()>0){
            TruyenYeuThich home = this.arr.get(position);
            TextView tenTenTranh =  convertView.findViewById(R.id.txvTenTruyen);
            TextView tenTenChap =  convertView.findViewById(R.id.txvtenchap);
            ImageView imgAnhtruyen =  convertView.findViewById(R.id.imgAnhTruyen);
             tenTenTranh.setText(home.getTentruyen());
             tenTenChap.setText(home.getTenchap());
            Glide.with(this.ct).load(home.getLinkAnh()).into(imgAnhtruyen);



        }

        return convertView;
    }












}

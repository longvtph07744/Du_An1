package com.example.apptruyentranhh;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import com.example.apptruyentranhh.adapter.TruyenTranh_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public ViewFlipper viewFlipper;
    ArrayList<Truyentranh> truyentranhArrayList;
    TruyenTranh_Adapter adapter;


    EditText timkiem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//adapter = new TruyenTranh_Adapter(this,truyentranhArrayList);

        Bundle bundle = new Bundle();

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.i, R.id.navigation_home, R.id.navigation_lichsu, R.id.navigation_lichsu)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);



        viewFlipper = findViewById(R.id.vf);
        Side_Anh();

        timkiem = findViewById(R.id.timkiem);
         init();

//        new ApiLayTruyen(this).execute();
//        setup();
        setonclick();
    }



    private void init() {
//        truyentranhArrayList = new ArrayList<>();
//        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca", "Chapter 17", "https://3.bp.blogspot.com/-v2dWdLlUifI/WxdK_QyJgbI/AAAAAAAAU-A/t64TS_b7QOUsbT4-uPhxtyMGFnmnNrtkACHMYCw/vua-quai-vat-va-nang-cong-chua-hien-te"));
//        truyentranhArrayList.add(new Truyentranh("Ta Là Đại Thần  ", "Chapter 5", "https://3.bp.blogspot.com/-gBNk3Lqqj0k/W8ya_FF2MxI/AAAAAAAAaFg/PCTRbB4KjEktAjYKoj8JLB6_uLZLBj70gCHMYCw/ta-la-dai-than-tien"));
//        truyentranhArrayList.add(new Truyentranh(" Long Hổ Môn", "Chapter 6", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));
//        truyentranhArrayList.add(new Truyentranh("A Returner's Magic Should Be ", "Chapter 1016", "https://3.bp.blogspot.com/-ttMOjytcdns/XApR71NP6mI/AAAAAAAAbLY/gexnur0r__8UHPwm7iaG_w3QErMnAocPACHMYCw/a-returners-magic-should-be-special"));
//        truyentranhArrayList.add(new Truyentranh("Tuyệt Thế Chiến Hồn", "Chapter 50.5", "https://3.bp.blogspot.com/-ye-GN4Nze10/XDWe2hm9QKI/AAAAAAAAb6E/ccxKNY_j80sgOZPkFsujLY67ru0XCe7UQCHMYCw/tuyet-the-chien-hon"));
//        truyentranhArrayList.add(new Truyentranh("Thú giữ nhà của đường Tây Tử", "Chapter 6", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROwDFDB-3phSsJs1zDLIN-eayOldP3nZO2TUwEB8_HhPJ6HagE&s"));
//        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca", "Chapter 17", "https://3.bp.blogspot.com/-U82kpymUB9w/V5ZMT6TLXjI/AAAAAAAAA6o/spbsT3lC2Ac/great-teacher-onizuka-paradise-lost.jpg"));
//        truyentranhArrayList.add(new Truyentranh("Danh Môn Chí Ái", "Chapter 50.5", "https://3.bp.blogspot.com/-NPzw42KezrY/V5amCHSk6BI/AAAAAAAAD9k/KtS-cLK4bSg/pastel.jpg"));
//        truyentranhArrayList.add(new Truyentranh("Hành Trình Đế Vương", "Chapter 1016", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));
//
//        adapter = new TruyenTranh_Adapter(this, 0, truyentranhArrayList);


    }


    public void setonclick () {

//        timkiem.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//            String s = timkiem.getText().toString();
//            adapter.sortTruyen(s);
//
//            }
//
//        });

    }



    private void Side_Anh() {
        ArrayList<String> sidearm = new ArrayList<>();


        sidearm.add("https://get.wallhere.com/photo/illustration-anime-manga-cartoon-comics-screenshot-computer-wallpaper-45335.jpg");
        sidearm.add("https://chuuniotaku.com/wp-content/uploads/2019/09/code-geass-hangyaku-no-lelouch-banner.jpg");
        sidearm.add("https://chuuniotaku.com/wp-content/uploads/2019/09/ao-no-exorcist-banner.jpg");
        sidearm.add("https://chuuniotaku.com/wp-content/uploads/2019/09/kuroshitsuji-book-of-circus-banner.jpg");


        sidearm.add("https://thegioidienanh.vn/stores/news_dataimages/huonggiang/052018/05/10/3827_ThYn_YYng_YYt_ViYt_2.jpg");
        sidearm.add("https://i.imgur.com/O3L9MOt.png");
        sidearm.add("https://genknews.genkcdn.vn/2019/5/7/photo-1-1557228146635626126519-crop-1557228203131655890479.png");



        sidearm.add("https://www.google.com/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwjj65fil6vmAhUEQd4KHVXfBhcQjRx6BAgBEAQ&url=%2Furl%3Fsa%3Di%26source%3Dimages%26cd%3D%26ved%3D2ahUKEwjKp9jbl6vmAhXU7WEKHTCCCzIQjRx6BAgBEAQ%26url%3Dhttps%253A%252F%252Framenparados.com%252Flos-mangas-y-novelas-ligeras-mas-vendidos-en-japon-durante-este-2018%252F%26psig%3DAOvVaw2TwlX4cAR1NoxzIjCNkz4w%26ust%3D1576070721529426&psig=AOvVaw2TwlX4cAR1NoxzIjCNkz4w&ust=1576070721529426");



        for (int i = 0; i < sidearm.size(); i++) {

            ImageView imageView = new ImageView(getApplicationContext());


            Picasso.with(getApplicationContext()).load(sidearm.get(i)).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            Log.e(imageView.toString(), "aaaa");
            viewFlipper.addView(imageView);
        }
        viewFlipper.setFlipInterval(5000);
        viewFlipper.setAutoStart(true);
        Animation animation_side = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.silde);
        Animation animation_side_out = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.silde_ou);
        viewFlipper.setInAnimation(animation_side);
        viewFlipper.setInAnimation(animation_side_out);

    }




}

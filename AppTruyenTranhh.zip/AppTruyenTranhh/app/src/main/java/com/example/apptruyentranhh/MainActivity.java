package com.example.apptruyentranhh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import com.example.apptruyentranhh.adapter.TruyenTranh_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public ViewFlipper viewFlipper;
    ArrayList<Truyentranh> truyentranhArrayList;
    TruyenTranh_Adapter adapter;
    EditText timkiem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Bundle bundle = new Bundle();

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.i, R.id.navigation_home, R.id.navigation_lichsu, R.id.navigation_lichsu)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);


        viewFlipper = findViewById(R.id.vf);
        Side_Anh();
        timkiem = findViewById(R.id.timkiem);

        setonclick();
    }

    public void setonclick () {

//        timkiem.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//            String s = timkiem.getText().toString();
//            adapter.sortTruyen(s);
//
//            }
//
//        });}
    }


    private void Side_Anh() {
        ArrayList<String> sidearm = new ArrayList<>();
        sidearm.add("https://thegioidienanh.vn/stores/news_dataimages/huonggiang/052018/05/10/3827_ThYn_YYng_YYt_ViYt_2.jpg");
        sidearm.add("https://media.ohay.tv/v1/content/2015/09/1-ohay-tv-16163.jpg");
        sidearm.add("https://media.ohay.tv/v1/content/2015/09/2-ohay-tv-40982.jpg");
        sidearm.add("https://i.imgur.com/O3L9MOt.png");

        sidearm.add("https://genknews.genkcdn.vn/2019/5/7/photo-1-1557228146635626126519-crop-1557228203131655890479.png");


        for (int i = 0; i < sidearm.size(); i++) {

            ImageView imageView = new ImageView(getApplicationContext());


            Picasso.with(getApplicationContext()).load(sidearm.get(i)).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            Log.e(imageView.toString(), "aaaa");
            viewFlipper.addView(imageView);
        }
        viewFlipper.setFlipInterval(5000);
        viewFlipper.setAutoStart(true);
        Animation animation_side = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.silde);
        Animation animation_side_out = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.silde_ou);
        viewFlipper.setInAnimation(animation_side);
        viewFlipper.setInAnimation(animation_side_out);

    }


}

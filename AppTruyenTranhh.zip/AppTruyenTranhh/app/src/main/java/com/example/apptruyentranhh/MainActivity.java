package com.example.apptruyentranhh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import com.example.apptruyentranhh.adapter.TruyenTranh_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public ViewFlipper viewFlipper ;
   GridView gdvdstruyen;
   ArrayList<Truyentranh> truyentranhArrayList;
   TruyenTranh_Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gdvdstruyen = findViewById(R.id.gdvDSTruyen);
        viewFlipper = findViewById(R.id.vf);
        Side_Anh();
        init();
        setup();
        setonclick();
    }

    private void setonclick() {
        gdvdstruyen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Truyentranh truyentranh = truyentranhArrayList.get(i);
                Bundle b = new Bundle();
                b.putSerializable("truyen",truyentranh);

                Intent intent = new Intent(MainActivity.this,ChapActivity.class);
                 intent.putExtra("data",b);
                startActivity(intent);
            }
        });
    }

    private void setup() {
        gdvdstruyen.setAdapter(adapter);
        
    }

    private void init() {
        truyentranhArrayList = new ArrayList<>();
        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca","Chapter 17","https://3.bp.blogspot.com/-eOVfNyyGZHs/WsC0ECE_auI/AAAAAAAAR8E/eOp0cA8DgEwur9hVvCWJKtanlXvPTmNggCHMYCw/huyet-ma-nhan") );
        truyentranhArrayList.add(new Truyentranh("Ta Là Đại Thần  ","Chapter 5","https://3.bp.blogspot.com/-gBNk3Lqqj0k/W8ya_FF2MxI/AAAAAAAAaFg/PCTRbB4KjEktAjYKoj8JLB6_uLZLBj70gCHMYCw/ta-la-dai-than-tien") );
        truyentranhArrayList.add(new Truyentranh(" Long Hổ Môn","Chapter 6","https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon") );
        truyentranhArrayList.add(new Truyentranh("A Returner's Magic Should Be ","Chapter 1016","https://3.bp.blogspot.com/-ttMOjytcdns/XApR71NP6mI/AAAAAAAAbLY/gexnur0r__8UHPwm7iaG_w3QErMnAocPACHMYCw/a-returners-magic-should-be-special") );
        truyentranhArrayList.add(new Truyentranh("Tuyệt Thế Chiến Hồn","Chapter 50.5","https://3.bp.blogspot.com/-ye-GN4Nze10/XDWe2hm9QKI/AAAAAAAAb6E/ccxKNY_j80sgOZPkFsujLY67ru0XCe7UQCHMYCw/tuyet-the-chien-hon") );
        truyentranhArrayList.add(new Truyentranh("Thú giữ nhà của đường Tây Tử","Chapter 6","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROwDFDB-3phSsJs1zDLIN-eayOldP3nZO2TUwEB8_HhPJ6HagE&s") );
        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca","Chapter 17","https://3.bp.blogspot.com/-U82kpymUB9w/V5ZMT6TLXjI/AAAAAAAAA6o/spbsT3lC2Ac/great-teacher-onizuka-paradise-lost.jpg") );
        truyentranhArrayList.add(new Truyentranh("Danh Môn Chí Ái","Chapter 50.5","https://3.bp.blogspot.com/-NPzw42KezrY/V5amCHSk6BI/AAAAAAAAD9k/KtS-cLK4bSg/pastel.jpg") );
        truyentranhArrayList.add(new Truyentranh("Hành Trình Đế Vương","Chapter 1016","https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon") );

        adapter = new TruyenTranh_Adapter(this,0,truyentranhArrayList);


    }


    private void Side_Anh() {
        ArrayList<String> sidearm = new ArrayList<>();
        sidearm.add("https://thegioidienanh.vn/stores/news_dataimages/huonggiang/052018/05/10/3827_ThYn_YYng_YYt_ViYt_2.jpg");
        sidearm.add("https://media.ohay.tv/v1/content/2015/09/1-ohay-tv-16163.jpg");
        sidearm.add("https://media.ohay.tv/v1/content/2015/09/2-ohay-tv-40982.jpg");
        sidearm.add("https://i.imgur.com/O3L9MOt.png");

        sidearm.add("https://genknews.genkcdn.vn/2019/5/7/photo-1-1557228146635626126519-crop-1557228203131655890479.png");






        for (int i = 0; i < sidearm.size(); i++) {

            ImageView imageView = new ImageView(getApplicationContext());


            Picasso.with(getApplicationContext()).load(sidearm.get(i)).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            Log.e(imageView.toString(),"aaaa");
            viewFlipper.addView(imageView);
        }
        viewFlipper.setFlipInterval(5000);
        viewFlipper.setAutoStart(true);
        Animation animation_side = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.silde);
        Animation animation_side_out = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.silde_ou);
        viewFlipper.setInAnimation(animation_side);
        viewFlipper.setInAnimation(animation_side_out);

    }


    public void thuvien(View view) {
        Intent intent = new Intent(MainActivity.this,Thu_Vien.class);
        startActivity(intent);
    }

    public void theodoi(View view) {
        Intent intent = new Intent(MainActivity.this,TheoDoi.class);
        startActivity(intent);
    }

    public void home(View view) {
        Intent intent = new Intent(MainActivity.this,MainActivity.class);
        startActivity(intent);
    }

    public void lichsu(View view) {
        Intent intent = new Intent(MainActivity.this,Lich_Su.class);
        startActivity(intent);
    }
}

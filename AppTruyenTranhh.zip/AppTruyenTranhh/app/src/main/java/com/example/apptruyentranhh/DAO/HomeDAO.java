package com.example.apptruyentranhh.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.apptruyentranhh.Database.DatabaseHelper;
import com.example.apptruyentranhh.object.Home;

import java.util.ArrayList;
import java.util.List;

public class HomeDAO { public static final String TABLE_NAME = "TrangChu";
//    public static final String SQL_TRANG_CHU = "CREATE TABLE TrangChu (id INTEGER PRIMARY KEY AUTOINCREMENT,tentruyen text, tenchap text, linkanh text);";
//             static final String TAG = "TrangChu";
//    private SQLiteDatabase db;
//    private DatabaseHelper dbHelper;
//
//    public HomeDAO(Context context) {
//        dbHelper = new DatabaseHelper(context);
//        db = dbHelper.getWritableDatabase();
//    }
//
//    public boolean insertTrangChu(Home trangChu) {
//        ContentValues values = new ContentValues();
////        values.put("id", trangChu.getId());
//        values.put("tentruyen", trangChu.getTentruyen());
//        values.put("tenchap", trangChu.getTenchap());
//        values.put("linkanh", trangChu.getLinkAnh());
//
//        long result = db.insert(TABLE_NAME, null, values);
//
//        try {
//            if (result == -1) {
//                return false;
//            }
//        } catch (Exception ex) {
//            Log.e(TAG, ex.toString());
//            return false;
//        }
//        return true;
//    }
//
//    public List<Home> getAllTrangChu() {
//        List<Home> dsTrangChu = new ArrayList<>();
//        Cursor c = db.query(TABLE_NAME, null, null, null, null, null, null);
//        c.moveToFirst();
//        while (c.isAfterLast() == false) {
//            Home ee = new Home();
////            ee.setId(c.getString(0));
//            ee.setTentruyen(c.getString(1));
//            ee.setTenchap(c.getString(2));
//            ee.setLinkAnh(c.getString(3));
//
//            dsTrangChu.add(ee);
//            Log.d("//======", ee.toString());
//            c.moveToNext();
//
//        }
//        c.close();
//        return dsTrangChu;
//    }
//
//    //delete
//    public int deleteTrangChuID(String id) {
//        int result = db.delete(TABLE_NAME, "id=?", new String[]{id});
//        if (result == 0) return -1;
//        return 1;
//    }
}

package com.example.apptruyentranhh;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.apptruyentranhh.api.ApiLayAnh;
import com.example.apptruyentranhh.intenface.LayAnhVe;
import com.example.apptruyentranhh.object.Home;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class DocTruyen extends AppCompatActivity implements LayAnhVe {
ImageView imganh;
ArrayList<String> arrUrlAnh;
int sotrang, sotrangdangdoc;
String idChap;
TextView txvSoTrang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_truyen);
        imganh = findViewById(R.id.imgAnh);
        txvSoTrang = findViewById(R.id.txtsotrang);

        init();
        setup();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        new ApiLayAnh(this,idChap).execute();



    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }



    private void setup() {


    }

    private void   init() {
        Bundle b = getIntent().getBundleExtra("data");
      idChap=b.getString("idChap");
//        arrUrlAnh = new ArrayList<>();
//        arrUrlAnh.add("https://1.bp.blogspot.com/-RRkoSnw-aNE/XZ7nEZpl2wI/AAAAAAACU6E/uTdhZ2vmdAge9pDZSE0ai_UQN-xHrA_BwCLcBGAsYHQ/s1600/0.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-0QHXpqId1hw/XZ7nFwaopFI/AAAAAAACU6Q/DmGWC8IrvhoXpunmfVKrasb9RxUYHimOgCLcBGAsYHQ/s1600/0001.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-u8pSwvovXEA/XZ7nF_5Ob9I/AAAAAAACU6M/D1TxMIHHvGsgjCH4phFzig3wpuCs7XyugCLcBGAsYHQ/s1600/0002.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-PJlMgOwBe2k/XZ7nGv6n6xI/AAAAAAACU6U/KtATzI42XRYC8Fq3X-qtBgqAJVIl3KFCgCLcBGAsYHQ/s1600/0004.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-YeIqirXPabI/XZ7nHfbGxxI/AAAAAAACU6c/cp22olwZ3Xc2BAVY4VKA2fDuhYknYEPuwCLcBGAsYHQ/s1600/0006.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-CZx7RHUy0AI/XZ7nH6PoNrI/AAAAAAACU6k/o4hwp_wLfS4KZdDAQBY1PCbXwP2Yyp_xACLcBGAsYHQ/s1600/0008.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-4NTNLIEG_2Y/XZ7nIwMz3TI/AAAAAAACU60/snf_P0pCKqY1EWpVN3EiVeOwmdX9OU9IwCLcBGAsYHQ/s1600/0011.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-ELQBXyUAKj4/XZ7nKNF5CBI/AAAAAAACU64/58ZOgFjRasoMaQXEOoVKvZ2z9gaBc0y3ACLcBGAsYHQ/s1600/0012.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-YnSNAyfGNDM/XZ7nKQ22qRI/AAAAAAACU68/k-tPfOBxecQCWUWAGeD1w3Im9Ds72PS0wCLcBGAsYHQ/s1600/0013.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-X92LQNoIGU0/XZ7nLJy5BvI/AAAAAAACU7A/FbzIYPhyxW8pi-JjJaotHFB1Q1p1G-ZkgCLcBGAsYHQ/s1600/0014.jpg?imgmax=0");
//
//        arrUrlAnh.add("https://1.bp.blogspot.com/-X92LQNoIGU0/XZ7nLJy5BvI/AAAAAAACU7A/FbzIYPhyxW8pi-JjJaotHFB1Q1p1G-ZkgCLcBGAsYHQ/s1600/0014.jpg?imgmax=0");
//
//        sotrangdangdoc = 1;
//              sotrang = arrUrlAnh.size();

    }

    public void left(View view) {
        doctheotrang(-1);
    }

    public void right(View view) {
        doctheotrang(1);
    }


    private void doctheotrang(int i ){
        sotrangdangdoc = sotrangdangdoc+i;
        if (sotrangdangdoc==0){
            sotrangdangdoc=1;
        }
        if (sotrangdangdoc>sotrang){
            sotrangdangdoc =sotrang;

        }
        txvSoTrang.setText(sotrangdangdoc+"/"+sotrang);
        Glide.with(this).load(arrUrlAnh.get(sotrangdangdoc-1)).into(imganh);
    }

    @Override
    public void batDau() {
        Toast.makeText(this,"Lay truyen",Toast.LENGTH_SHORT).show();

    }

    @Override
    public void ketThuc(String data) {
        arrUrlAnh = new ArrayList<>();

        try {
            JSONArray arr = new JSONArray(data);
            for (int i = 0; i<arr.length();i++){
            arrUrlAnh.add(arr.getString(i));
            }
            sotrangdangdoc = 1;

            sotrang = arrUrlAnh.size();
            doctheotrang(0);

        }catch (JSONException e){

        }


    }

    @Override
    public void biLoi() {

    }
}

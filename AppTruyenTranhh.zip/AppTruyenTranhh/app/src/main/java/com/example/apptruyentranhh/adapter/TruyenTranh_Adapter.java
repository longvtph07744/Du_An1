package com.example.apptruyentranhh.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.apptruyentranhh.Lich_Su;
import com.example.apptruyentranhh.MainActivity;
import com.example.apptruyentranhh.R;
import com.example.apptruyentranhh.TheoDoi;
import com.example.apptruyentranhh.Thu_Vien;
import com.example.apptruyentranhh.object.Truyentranh;

import java.util.ArrayList;
import java.util.List;


public class TruyenTranh_Adapter extends ArrayAdapter<Truyentranh> {
    private Context ct;
    private ArrayList<Truyentranh> arr;
    public TruyenTranh_Adapter(MainActivity context, int resource, List<Truyentranh> objects) {
        super(context, resource, objects);
        this.ct = context;
        this.arr = new ArrayList<>(objects);
    }
    public TruyenTranh_Adapter(Thu_Vien context, int resource, List<Truyentranh> objects) {
        super(context, resource, objects);
        this.ct = context;
        this.arr = new ArrayList<>(objects);
    }
    public TruyenTranh_Adapter(Lich_Su context, int resource, List<Truyentranh> objects) {
        super(context, resource, objects);
        this.ct = context;
        this.arr = new ArrayList<>(objects);
    }




    @Override
    public View getView(int position, View convertView,  ViewGroup parent) {
        if (convertView==null){
            LayoutInflater inflater = (LayoutInflater)ct.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.item_truyen,null);
        }
        if (arr.size()>0){
            Truyentranh truyentranh = this.arr.get(position);
            TextView tenTenTranh =  convertView.findViewById(R.id.txvTenTruyen);
            TextView tenTenChap =  convertView.findViewById(R.id.txvtenchap);
            ImageView imgAnhtruyen =  convertView.findViewById(R.id.imgAnhTruyen);
             tenTenTranh.setText(truyentranh.getTentruyen());
             tenTenChap.setText(truyentranh.getTenchap());
            Glide.with(this.ct).load(truyentranh.getLinkAnh()).into(imgAnhtruyen);



        }
        return convertView;
    }

}

package com.example.apptruyentranhh.fragment.theloai;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.apptruyentranhh.ChapActivity;
import com.example.apptruyentranhh.MainActivity;
import com.example.apptruyentranhh.R;
import com.example.apptruyentranhh.adapter.TruyenTranh_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;

import java.util.ArrayList;


public class TheLoaiFragment extends Fragment {

    public ViewFlipper viewFlipper;

    GridView gdvdstruyen;
    ArrayList<Truyentranh> truyentranhArrayList;
    TruyenTranh_Adapter adapter;
    MainActivity mainActivity;
    EditText timkiem;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_theloai, container, false);

        Bundle arguments = getArguments();


        gdvdstruyen = root.findViewById(R.id.gdvDSTruyen);
        viewFlipper = root.findViewById(R.id.vf);

        timkiem = root.findViewById(R.id.timkiem);




//        notificationsViewModel =
//                ViewModelProviders.of(this).get(NotificationsViewModel.class);
//        notificationsViewModel.getText().observe(this, new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        init();
        setup();
        setonclick();

        return root;

    }




    private void setup() {
        gdvdstruyen.setAdapter(adapter);

    }

    private void init() {
        truyentranhArrayList = new ArrayList<>();
        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca", "Chapter 17", "https://3.bp.blogspot.com/-v2dWdLlUifI/WxdK_QyJgbI/AAAAAAAAU-A/t64TS_b7QOUsbT4-uPhxtyMGFnmnNrtkACHMYCw/vua-quai-vat-va-nang-cong-chua-hien-te"));
        truyentranhArrayList.add(new Truyentranh("Ta Là Đại Thần  ", "Chapter 5", "https://3.bp.blogspot.com/-gBNk3Lqqj0k/W8ya_FF2MxI/AAAAAAAAaFg/PCTRbB4KjEktAjYKoj8JLB6_uLZLBj70gCHMYCw/ta-la-dai-than-tien"));
        truyentranhArrayList.add(new Truyentranh(" Long Hổ Môn", "Chapter 6", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));
        truyentranhArrayList.add(new Truyentranh("A Returner's Magic Should Be ", "Chapter 1016", "https://3.bp.blogspot.com/-ttMOjytcdns/XApR71NP6mI/AAAAAAAAbLY/gexnur0r__8UHPwm7iaG_w3QErMnAocPACHMYCw/a-returners-magic-should-be-special"));
        truyentranhArrayList.add(new Truyentranh("Tuyệt Thế Chiến Hồn", "Chapter 50.5", "https://3.bp.blogspot.com/-ye-GN4Nze10/XDWe2hm9QKI/AAAAAAAAb6E/ccxKNY_j80sgOZPkFsujLY67ru0XCe7UQCHMYCw/tuyet-the-chien-hon"));
        truyentranhArrayList.add(new Truyentranh("Thú giữ nhà của đường Tây Tử", "Chapter 6", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROwDFDB-3phSsJs1zDLIN-eayOldP3nZO2TUwEB8_HhPJ6HagE&s"));
        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca", "Chapter 17", "https://3.bp.blogspot.com/-U82kpymUB9w/V5ZMT6TLXjI/AAAAAAAAA6o/spbsT3lC2Ac/great-teacher-onizuka-paradise-lost.jpg"));
        truyentranhArrayList.add(new Truyentranh("Danh Môn Chí Ái", "Chapter 50.5", "https://3.bp.blogspot.com/-NPzw42KezrY/V5amCHSk6BI/AAAAAAAAD9k/KtS-cLK4bSg/pastel.jpg"));
        truyentranhArrayList.add(new Truyentranh("Hành Trình Đế Vương", "Chapter 1016", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));

        adapter = new TruyenTranh_Adapter(getContext(), 0, truyentranhArrayList);


    }
    private void setonclick() {
//
//
//        timkiem.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                String s = timkiem.getText().toString();
//                adapter.sortTruyen(s);
//
//            }
//
//        });

        gdvdstruyen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Truyentranh truyentranh = truyentranhArrayList.get(i);
                Bundle b = new Bundle();
                b.putSerializable("truyen", truyentranh);

                Intent intent = new Intent(getContext(), ChapActivity.class);
                intent.putExtra("data", b);
                startActivity(intent);
            }
        });
    }


}
package com.example.apptruyentranhh.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.apptruyentranhh.Database.DatabaseHelper;
import com.example.apptruyentranhh.object.Home;
import com.example.apptruyentranhh.object.TruyenYeuThich;

import java.util.ArrayList;
import java.util.List;

public class YeuThichDAO { public static final String TABLE = "YeuThich";
    public static final String SQL_TRUYEN_YEU_THICH =   "CREATE TABLE YeuThich (id INTEGER PRIMARY KEY AUTOINCREMENT,tentruyen text, tenchap text, linkanh text);";
    private static final String TAG = "YeuThich";
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;

    public YeuThichDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public boolean iserttruyen(Home trangChu) {
        ContentValues values = new ContentValues();

//        values.put("id",trangChu.getId());
        values.put("tentruyen", trangChu.getTentruyen());
        values.put("tenchap", trangChu.getTenchap());
        values.put("linkanh", trangChu.getLinkAnh());

        long result = db.insert(TABLE, null, values);

        try {
            if (result == -1) {
                return false;
            }
        } catch (Exception ex) {
            Log.e(TAG, ex.toString());
            return false;
        }
        return true;
    }

    public List<TruyenYeuThich> getAllTruyenYeuThich() {
        List<TruyenYeuThich> dsTrangChu = new ArrayList<>();
        Cursor c = db.query(TABLE, null, null, null, null, null, null);
        c.moveToFirst();
        while (c.isAfterLast() == false) {
            TruyenYeuThich ee = new TruyenYeuThich();
            ee.setId(c.getString(0));
            ee.setTentruyen(c.getString(1));
            ee.setTenchap(c.getString(2));
            ee.setLinkAnh(c.getString(3));

            dsTrangChu.add(ee);
            Log.d("//======", ee.toString());
            c.moveToNext();

        }
        c.close();
        return dsTrangChu;
    }

    //delete
    public int deleteTruyenYeuThichTrangChuID(int id) {
        int result = db.delete(TABLE, "id=?", new String[]{String.valueOf(id)});
        if (result == 0) return -1;
        return 1;
    }
}


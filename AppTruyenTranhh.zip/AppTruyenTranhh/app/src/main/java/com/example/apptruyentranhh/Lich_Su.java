package com.example.apptruyentranhh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ViewFlipper;

import com.example.apptruyentranhh.adapter.TruyenTranh_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;

import java.util.ArrayList;

public class Lich_Su extends AppCompatActivity {
    GridView gdvdstruyen;
    ArrayList<Truyentranh> truyentranhArrayList;
    TruyenTranh_Adapter adapter_;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lich__su);

        gdvdstruyen = findViewById(R.id.gdvDSTruyen);

        init();
        setup();
        setonclick();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void setonclick() {
        gdvdstruyen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Truyentranh truyentranh = truyentranhArrayList.get(i);
                Bundle b = new Bundle();
                b.putSerializable("truyen", truyentranh);

                Intent intent = new Intent(Lich_Su.this, ChapActivity.class);
                intent.putExtra("data", b);
                startActivity(intent);
            }
        });
    }

    private void setup() {
        gdvdstruyen.setAdapter(adapter_);

    }

    private void init() {
        truyentranhArrayList = new ArrayList<>();
        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca", "Đã xem", "https://3.bp.blogspot.com/-uKfnUKn4l1U/WBNE061U2pI/AAAAAAAAMlU/1w4WeeLfdJ0/hatsukoi-zombie.jpg"));
        truyentranhArrayList.add(new Truyentranh("Thiên thần ", "Đã xem", "https://3.bp.blogspot.com/-22po55yUNXo/Wo9z08YchEI/AAAAAAAAP0M/HOo5VSjyXgs3YHLNPczvLJNH5OMlz6_NwCHMYCw/trai-tim-va-than-xac-blush-dc-himitsu"));
        truyentranhArrayList.add(new Truyentranh("Đường Tây Tử", "Đã xem", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));
        truyentranhArrayList.add(new Truyentranh("Tân Tác Long Hổ Môn", "Đã xem", "https://3.bp.blogspot.com/-fUUIZ4Fh0y4/Wo9nz9jZ3TI/AAAAAAAANi4/oJ28Retz8BYvLobtj3kZC1Qq9RtDoF5pwCHMYCw/vuong-tuoc-tu-huu-bao-boi"));
        truyentranhArrayList.add(new Truyentranh("Danh Môn Chí Ái", "Đã xem", "https://3.bp.blogspot.com/-kgHjaI_K7GU/WqdkxteJZ3I/AAAAAAAARXI/ax6XxDzfl1kW-u88I4_GUDgUsi57OeyYwCHMYCw/nhan-chat-tinh-nhan"));

        adapter_ = new TruyenTranh_Adapter(this, 0, truyentranhArrayList);


    }

    public void thuvien(View view) {
        Intent intent = new Intent(Lich_Su.this, Thu_Vien.class);
        startActivity(intent);
    }

    public void theodoi(View view) {
        Intent intent = new Intent(Lich_Su.this, TheoDoi.class);
        startActivity(intent);
    }

    public void home(View view) {
        Intent intent = new Intent(Lich_Su.this, MainActivity.class);
        startActivity(intent);
    }

    public void lichsu(View view) {
        Intent intent = new Intent(Lich_Su.this, Lich_Su.class);
        startActivity(intent);
    }


}

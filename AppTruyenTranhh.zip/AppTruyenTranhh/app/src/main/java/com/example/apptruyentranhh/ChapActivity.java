package com.example.apptruyentranhh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.apptruyentranhh.DAO.YeuThichDAO;
import com.example.apptruyentranhh.adapter.ChapTruyenAdapter;
import com.example.apptruyentranhh.api.ApiLayChap;
import com.example.apptruyentranhh.intenface.LayChapVe;
import com.example.apptruyentranhh.object.ChapTruyen;
import com.example.apptruyentranhh.object.Home;
import com.example.apptruyentranhh.fragment.home.HomeFragment;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class ChapActivity extends AppCompatActivity implements LayChapVe {
    TextView txvtentruyen;
    ImageView IMGAnhTruyen;
    Home truyentranh;
    ListView lsvdanhsachchap;
    ArrayList<ChapTruyen> arrchap;
    ChapTruyenAdapter chapTruyenAdapter;
    Button btttheodoi;
    YeuThichDAO yeuThichDAO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chap);
        txvtentruyen = findViewById(R.id.txtTenTruyen);
        IMGAnhTruyen = findViewById(R.id.IMGAnhTruyen);
        lsvdanhsachchap = findViewById(R.id.lsvdanhsachchap);
        btttheodoi = findViewById(R.id.theodoi);
        yeuThichDAO = new YeuThichDAO(this);


        init();
        setup();
        setclik();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        new ApiLayChap(this,truyentranh.getId()).execute();
    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    private void init() {
        Bundle b = getIntent().getBundleExtra("data");
        truyentranh = (Home) b.getSerializable("truyen");
        // du lieu ao
        arrchap = new ArrayList<>();
//        for (int i = 0; i < 30; i++) {
//            arrchap.add(new ChapTruyen("Chapter" + i, "01-12-2020"));
//
//
//        }
//        chapTruyenAdapter = new ChapTruyenAdapter(this, 0, arrchap);
    }

    private void setup() {
        txvtentruyen.setText(truyentranh.getTentruyen());
        Glide.with(this).load(truyentranh.getLinkAnh()).into(IMGAnhTruyen);
//        lsvdanhsachchap.setAdapter(chapTruyenAdapter);

    }

    private void setclik() {
        lsvdanhsachchap.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bundle b = new Bundle();
                b.putString("idChap", arrchap.get(i).getId());

                Intent intent = new Intent(ChapActivity.this, DocTruyen.class);
                intent.putExtra("data", b);
                startActivity(intent);
            }
        });


    }


    public void first(View view) {
//        startActivity(new Intent(ChapActivity.this, DocTruyen.class));

    }

    public void end(View view) {
//        startActivity(new Intent(ChapActivity.this, DocTruyen.class));

    }

    @Override
    public void batDau() {
        Toast.makeText(this, "Lay Chap Ve", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void ketThuc(String data) {
        try {
            JSONArray array = new JSONArray(data);
            for (int i = 0; i < array.length(); i++) {
                ChapTruyen chapTruyen = new ChapTruyen(array.getJSONObject(i));
                arrchap.add(chapTruyen);

            }
            chapTruyenAdapter = new ChapTruyenAdapter(this, 0, arrchap);
            lsvdanhsachchap.setAdapter(chapTruyenAdapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void biLoi() {

    }
}

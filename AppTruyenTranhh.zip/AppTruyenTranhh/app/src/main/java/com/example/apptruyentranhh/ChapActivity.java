package com.example.apptruyentranhh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.apptruyentranhh.adapter.ChapTruyenAdapter;
import com.example.apptruyentranhh.object.ChapTruyen;
import com.example.apptruyentranhh.object.Truyentranh;

import java.util.ArrayList;

public class ChapActivity extends AppCompatActivity {
TextView txvtentruyen;
ImageView IMGAnhTruyen;
Truyentranh truyentranh;
ListView lsvdanhsachchap;
ArrayList<ChapTruyen> arrchap;
ChapTruyenAdapter chapTruyenAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chap);
        txvtentruyen = findViewById(R.id.txtTenTruyen);
        IMGAnhTruyen = findViewById(R.id.IMGAnhTruyen);
        lsvdanhsachchap = findViewById(R.id.lsvdanhsachchap);
        init();
        setup();
        setclik();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }



    private void init(){
        Bundle b = getIntent().getBundleExtra("data");
        truyentranh =(Truyentranh) b.getSerializable("truyen");
       // du lieu ao
        arrchap = new ArrayList<>();
for (int i=0;i<30;i++){
    arrchap.add(new ChapTruyen("Chapter"+i,"01-12-2020"));


        }
      chapTruyenAdapter = new ChapTruyenAdapter(this,0,arrchap);
    }
    private void setup(){
        txvtentruyen.setText(truyentranh.getTentruyen());
        Glide.with(this).load(truyentranh.getLinkAnh()).into(IMGAnhTruyen);
       lsvdanhsachchap.setAdapter(chapTruyenAdapter);

    }
    private void setclik(){
        lsvdanhsachchap.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                startActivity(new Intent(ChapActivity.this,DocTruyen.class));
            }
        });
    }


}

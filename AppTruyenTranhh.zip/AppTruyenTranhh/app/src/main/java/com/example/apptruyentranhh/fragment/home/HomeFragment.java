package com.example.apptruyentranhh.fragment.home;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;


import com.example.apptruyentranhh.ChapActivity;
import com.example.apptruyentranhh.DAO.HomeDAO;
import com.example.apptruyentranhh.R;
import com.example.apptruyentranhh.adapter.Home_Adapter;
import com.example.apptruyentranhh.api.ApiLayTruyen;
import com.example.apptruyentranhh.intenface.LayTruyenVe;
import com.example.apptruyentranhh.object.Home;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements LayTruyenVe {
    private List<Home> trangchu;
    GridView gdvdstruyen;

    Home_Adapter adapter ;
    ArrayList<Home> truyentranhArrayList;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        Bundle arguments = getArguments();
        gdvdstruyen = root.findViewById(R.id.gdvDSTruyen);




        init();
        setonclick();
       new ApiLayTruyen(this).execute();

        return root;

    }


    private void init() {

        truyentranhArrayList = new ArrayList<>();

//        HomeDAO homeDAO = new HomeDAO(getContext());

//        homeDAO.insertTrangChu(new Home("1", "Bộ Thiên Ca", "Chapter 17", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));
//        homeDAO.insertTrangChu(new Home("2", "Ta Là Đại Thần", "Chapter 5", "https://3.bp.blogspot.com/-U82kpymUB9w/V5ZMT6TLXjI/AAAAAAAAA6o/spbsT3lC2Ac/great-teacher-onizuka-paradise-lost.jpg"));
//        homeDAO.insertTrangChu(new Home("3", "Long Hổ Môn", "Chapter 6", "https://3.bp.blogspot.com/-ttMOjytcdns/XApR71NP6mI/AAAAAAAAbLY/gexnur0r__8UHPwm7iaG_w3QErMnAocPACHMYCw/a-returners-magic-should-be-special"));
//        homeDAO.insertTrangChu(new Home("4", "A Returner's Magic Should Be", "Chapter 1016", "https://3.bp.blogspot.com/-ye-GN4Nze10/XDWe2hm9QKI/AAAAAAAAb6E/ccxKNY_j80sgOZPkFsujLY67ru0XCe7UQCHMYCw/tuyet-the-chien-hon"));
//        homeDAO.insertTrangChu(new Home("5", " Thú giữ nhà ", "sdfsd", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROwDFDB-3phSsJs1zDLIN-eayOldP3nZO2TUwEB8_HhPJ6HagE&s"));
//        homeDAO.insertTrangChu(new Home("6", "Tuyệt Thế Chiến Hồn", "sdfsd", "https://3.bp.blogspot.com/-gBNk3Lqqj0k/W8ya_FF2MxI/AAAAAAAAaFg/PCTRbB4KjEktAjYKoj8JLB6_uLZLBj70gCHMYCw/ta-la-dai-than-tien"));
//        homeDAO.insertTrangChu(new Home("7", "Hành Trình Đế Vương", "sdfsd", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));
//        homeDAO.insertTrangChu(new Home("8", "Danh Môn Chí Ái", "sdfsd", "https://3.bp.blogspot.com/-U82kpymUB9w/V5ZMT6TLXjI/AAAAAAAAA6o/spbsT3lC2Ac/great-teacher-onizuka-paradise-lost.jpg"));
//        homeDAO.insertTrangChu(new Home("9", "Tác giả: Nhĩ Nhã", "sdfsd", "https://3.bp.blogspot.com/-ye-GN4Nze10/XDWe2hm9QKI/AAAAAAAAb6E/ccxKNY_j80sgOZPkFsujLY67ru0XCe7UQCHMYCw/tuyet-the-chien-hon"));
//        trangchu = homeDAO.getAllTrangChu();
//        Home_Adapter trangChuAdapter = new Home_Adapter(getContext(), 0, trangchu);
//        gdvdstruyen.setAdapter(trangChuAdapter);
    }

    private void setonclick() {

//
//        timkiem.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                String s = timkiem.getText().toString();
//                adapter.sortTruyen(s);
//
//            }
//
//        });

        gdvdstruyen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Home truyentranh = truyentranhArrayList.get(i);
                Bundle b = new Bundle();
                b.putSerializable("truyen", truyentranh);

                Intent intent = new Intent(getContext(), ChapActivity.class);
                intent.putExtra("data", b);
                startActivity(intent);
            }
        });
    }


    @Override
    public void batDau() {
        Toast.makeText(getActivity(), "Dang lay ve", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void ketThuc(String data) {
        try {
            truyentranhArrayList.clear();
            JSONArray arr = new JSONArray(data);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                truyentranhArrayList.add(new Home(o));

            }
            adapter = new Home_Adapter(getContext(), 0, truyentranhArrayList);
            gdvdstruyen.setAdapter(adapter);

        } catch (JSONException e) {
        }

    }

    @Override
    public void biLoi() {
        Toast.makeText(getContext(), " Bi loi", Toast.LENGTH_SHORT).show();


    }




}
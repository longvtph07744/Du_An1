package com.example.apptruyentranhh.intenface;

public interface LayTruyenVe {
    void batDau();
    void ketThuc(String data);
    void  biLoi();

}

package com.example.apptruyentranhh.ui.theodoi;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.apptruyentranhh.ChapActivity;
import com.example.apptruyentranhh.R;
import com.example.apptruyentranhh.adapter.TruyenTranhDaDoc_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;

import java.util.ArrayList;

public class TheoDoiFragment extends Fragment {
    public ViewFlipper viewFlipper;
    GridView gdvdstruyen;
    ArrayList<Truyentranh> truyentranhArrayList;
    TruyenTranhDaDoc_Adapter adapter;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_theodoi, container, false);

        gdvdstruyen = root.findViewById(R.id.gdvDSTruyen);
        viewFlipper = root.findViewById(R.id.vf);

        init();
        setup();
        setonclick();
        return root;
    }


    private void setonclick() {
        gdvdstruyen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Truyentranh truyentranh = truyentranhArrayList.get(i);
                Bundle b = new Bundle();
                b.putSerializable("truyen", truyentranh);

                Intent intent = new Intent(getContext(), ChapActivity.class);
                intent.putExtra("data", b);
                startActivity(intent);
            }
        });
    }

    private void setup() {
        gdvdstruyen.setAdapter(adapter);

    }

    private void init() {
        truyentranhArrayList = new ArrayList<>();
        truyentranhArrayList.add(new Truyentranh("Ta Là Đại Thần  ", "Chapter 100", "https://3.bp.blogspot.com/-gBNk3Lqqj0k/W8ya_FF2MxI/AAAAAAAAaFg/PCTRbB4KjEktAjYKoj8JLB6_uLZLBj70gCHMYCw/ta-la-dai-than-tien"));

        adapter = new TruyenTranhDaDoc_Adapter(getContext(), 0, truyentranhArrayList);


    }
}
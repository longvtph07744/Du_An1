package com.example.apptruyentranhh.object;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Home implements Serializable {
    private String id,tenTruyen, tenChap, linkAnh;



/*
    {
    "id":"",
    "tenTruyen":"",
    "tenChap":"",
            "linkAnh":"",}

 */


    public Home(JSONObject o) throws JSONException {
        id = o.getString("id");
        tenTruyen = o.getString("tenTruyen");
        tenChap = o.getString("tenChap");
        linkAnh = o.getString("linkAnh");
    }

    public Home( String tenTruyen, String tenChap, String linkAnh) {
//        this.id = id;
        this.tenTruyen = tenTruyen;
        this.tenChap = tenChap;
        this.linkAnh = linkAnh;
    }

    public Home() {

    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTentruyen() {
        return tenTruyen;
    }

    public void setTentruyen(String tenTruyen) {
        this.tenTruyen = tenTruyen;
    }

    public String getTenchap() {
        return tenChap;
    }

    public void setTenchap(String tenChap) {
        this.tenChap = tenChap;
    }

    public String getLinkAnh() {
        return linkAnh;
    }

    public void setLinkAnh(String linkAnh) {
        this.linkAnh = linkAnh;
    }


}

package com.example.apptruyentranhh.object;

import java.io.Serializable;

public class TruyenYeuThich implements Serializable {
    private String id,tentruyen, tenchap, LinkAnh;

    public TruyenYeuThich() {

    }


//    {
////    "tentruyen":"",
////    "tenchap":"",
////            "linkAnh":"",}
//


    public TruyenYeuThich(String id, String tentruyen, String tenchap, String linkAnh) {
        this.id = id;
        this.tentruyen = tentruyen;
        this.tenchap = tenchap;
        LinkAnh = linkAnh;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTentruyen() {
        return tentruyen;
    }

    public void setTentruyen(String tentruyen) {
        this.tentruyen = tentruyen;
    }

    public String getTenchap() {
        return tenchap;
    }

    public void setTenchap(String tenchap) {
        this.tenchap = tenchap;
    }

    public String getLinkAnh() {
        return LinkAnh;
    }

    public void setLinkAnh(String linkAnh) {
        LinkAnh = linkAnh;
    }

    @Override
    public String toString() {
        return "Home{" +
                "id='" + id + '\'' +
                ", tentruyen='" + tentruyen + '\'' +
                ", tenchap='" + tenchap + '\'' +
                ", LinkAnh='" + LinkAnh + '\'' +
                '}';
    }
}

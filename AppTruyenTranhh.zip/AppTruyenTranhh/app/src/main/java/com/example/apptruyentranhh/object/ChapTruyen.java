package com.example.apptruyentranhh.object;

public class ChapTruyen {
    private String tenChap, ngaydang;

    public ChapTruyen(String tenChap, String ngaydang) {
        this.tenChap = tenChap;
        this.ngaydang = ngaydang;
    }

    public String getTenChap() {
        return tenChap;
    }

    public void setTenChap(String tenChap) {
        this.tenChap = tenChap;
    }

    public String getNgaydang() {
        return ngaydang;
    }

    public void setNgaydang(String ngaydang) {
        this.ngaydang = ngaydang;
    }
}

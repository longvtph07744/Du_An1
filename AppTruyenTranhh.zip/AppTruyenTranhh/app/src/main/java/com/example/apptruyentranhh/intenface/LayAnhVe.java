package com.example.apptruyentranhh.intenface;

public interface LayAnhVe {
    void batDau();
    void ketThuc(String data);
    void  biLoi();

}
